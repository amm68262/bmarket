# Bmarket — marketplace multi-vendeurs (starter fonctionnel)

Bmarket est un socle applicatif pour une marketplace internationale : catalogue public, boutiques vendeurs, comptes, commandes multi-vendeurs, espace vendeur et administration.

## Stack
- Next.js App Router + TypeScript
- Tailwind CSS
- Supabase (PostgreSQL, Auth, stockage)
- Paiement : à intégrer via un prestataire compatible avec le pays et le modèle marketplace choisi.

## Démarrage local
1. Installez Node.js LTS (20+), puis décompressez le projet.
2. Copiez `.env.example` vers `.env.local` et renseignez les clés Supabase.
3. Dans Supabase, exécutez `supabase/schema.sql` dans SQL Editor.
4. Dans le dossier du projet :
   ```bash
   npm install
   npm run dev
   ```
5. Ouvrez `http://localhost:3000`.

## Variables d'environnement
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` (serveur uniquement, ne jamais exposer au navigateur)

## Important avant production
Ce dépôt est un MVP de départ, pas un système déjà audité ou prêt à encaisser de l'argent. Avant d'ouvrir les ventes :
- configurer Supabase Auth, URLs de redirection et règles RLS ;
- implémenter les routes serveur pour créer/mettre à jour commandes et vérifier les prix en base ;
- intégrer et tester un prestataire de paiement autorisant les marketplaces et les versements aux vendeurs ;
- vérifier les obligations fiscales, consommateurs, données personnelles, sanctions et paiements pour chaque pays ;
- ajouter e-mails transactionnels, monitoring, sauvegardes, tests, anti-abus et gestion des retours/litiges ;
- enregistrer et configurer `bmarket.com` chez un registrar puis connecter le domaine à l'hébergement.

## Architecture
- `app/` pages et interfaces
- `components/` composants de présentation
- `lib/` client Supabase
- `supabase/schema.sql` tables, contraintes et politiques RLS de base

Les commandes sont conçues comme une commande principale avec une ou plusieurs sous-commandes vendeurs (`orders` + `order_items`). La livraison est gérée par chaque vendeur. Les nouveaux vendeurs restent en attente de validation administrative.
