import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
export const metadata: Metadata = { title: "Bmarket — Le commerce, sans frontières", description: "Découvrez des produits et des boutiques indépendantes sur Bmarket." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fr"><body><Header />{children}<footer className="mt-20 border-t border-slate-200 bg-white py-10 text-sm text-slate-500"><div className="container flex flex-col justify-between gap-4 md:flex-row"><span>© {new Date().getFullYear()} Bmarket</span><span>Marketplace indépendante · Français · English</span><span>Vendre sur Bmarket · Aide · Conditions</span></div></footer></body></html>;
}
