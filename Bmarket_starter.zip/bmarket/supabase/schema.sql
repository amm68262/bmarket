-- Bmarket schema starter. Review policies and business rules before production.
create extension if not exists pgcrypto;

create type public.app_role as enum ('customer','seller','admin');
create type public.seller_status as enum ('pending','approved','rejected','suspended');
create type public.product_status as enum ('draft','active','archived');
create type public.order_status as enum ('pending','confirmed','processing','shipped','delivered','cancelled','refunded');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role public.app_role not null default 'customer',
  preferred_locale text not null default 'fr',
  created_at timestamptz not null default now()
);

create table public.stores (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  slug text not null unique,
  description text,
  logo_url text,
  country_code char(2),
  status public.seller_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references public.categories(id) on delete set null,
  name text not null,
  slug text not null unique,
  is_active boolean not null default true
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  slug text not null,
  description text,
  price numeric(12,2) not null check (price >= 0),
  currency char(3) not null,
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  image_urls text[] not null default '{}',
  status public.product_status not null default 'draft',
  created_at timestamptz not null default now(),
  unique(store_id, slug)
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  order_number text not null unique,
  status public.order_status not null default 'pending',
  currency char(3) not null,
  subtotal numeric(12,2) not null check (subtotal >= 0),
  shipping_total numeric(12,2) not null default 0 check (shipping_total >= 0),
  total numeric(12,2) not null check (total >= 0),
  shipping_address jsonb not null,
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','pending','paid','failed','refunded','partially_refunded')),
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  store_id uuid not null references public.stores(id),
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  currency char(3) not null,
  seller_status public.order_status not null default 'pending',
  shipping_provider text,
  tracking_number text,
  seller_shipping_fee numeric(12,2) not null default 0 check (seller_shipping_fee >= 0),
  created_at timestamptz not null default now()
);

create table public.commission_rules (
  id uuid primary key default gen_random_uuid(),
  store_id uuid references public.stores(id) on delete cascade,
  rate_percent numeric(5,2) not null check (rate_percent >= 0 and rate_percent <= 100),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.subscription_plans (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  price_monthly numeric(10,2) not null check (price_monthly >= 0),
  currency char(3) not null default 'EUR',
  features jsonb not null default '{}',
  active boolean not null default true
);

create table public.seller_subscriptions (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  plan_id uuid not null references public.subscription_plans(id),
  provider_subscription_id text,
  status text not null default 'pending',
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  details jsonb not null default '{}',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.stores enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.commission_rules enable row level security;
alter table public.subscription_plans enable row level security;
alter table public.seller_subscriptions enable row level security;
alter table public.audit_logs enable row level security;

-- Profiles: users can read/update their own profile. Role changes must be server/admin-controlled.
create policy "profile read own" on public.profiles for select using (auth.uid() = id);
create policy "profile update own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- Public storefront reads: approved stores and active products only.
create policy "public read approved stores" on public.stores for select using (status = 'approved' or owner_id = auth.uid());
create policy "seller create own pending store" on public.stores for insert with check (owner_id = auth.uid() and status = 'pending');
create policy "seller update own store" on public.stores for update using (owner_id = auth.uid()) with check (owner_id = auth.uid() and status <> 'approved');

create policy "public read categories" on public.categories for select using (is_active = true);
create policy "public read active products" on public.products for select using (status = 'active' and exists(select 1 from public.stores s where s.id = store_id and s.status = 'approved'));
create policy "seller read own products" on public.products for select using (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));
create policy "seller add products to own store" on public.products for insert with check (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid() and s.status = 'approved'));
create policy "seller update own products" on public.products for update using (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid())) with check (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));

create policy "customer read own orders" on public.orders for select using (customer_id = auth.uid());
create policy "customer read own order items" on public.order_items for select using (exists(select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid()) or exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));
create policy "seller read own order items" on public.order_items for select using (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));

create policy "read active subscription plans" on public.subscription_plans for select using (active = true);
create policy "seller read own subscriptions" on public.seller_subscriptions for select using (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));

-- No client-side insert/update policy for orders, payment data, commission rules, subscriptions, audit logs,
-- or seller approvals. Add trusted server routes/functions with validated prices and authorization.
