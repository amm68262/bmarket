import type { Config } from "tailwindcss";
const config: Config = { content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"], theme: { extend: { colors: { brand: { 50:"#effcfb",100:"#d7f7f3",500:"#0f9f99",600:"#0b817d",700:"#116b68",900:"#123c45" } }, boxShadow: { soft:"0 12px 36px rgba(15, 45, 60, .08)" } } }, plugins: [] };
export default config;
